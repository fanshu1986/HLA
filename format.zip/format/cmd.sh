perl /lustre/work/shufan/bin/HLA_V2/align.nuc.pl -input ../A_nuc.txt -key A_nuc -od ./ -gene A
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl  -input ../A_gen.txt -key A_gen -od ./ -gene A
perl /lustre/work/shufan/bin/HLA_V2/align.nuc.pl -input ../B_nuc.txt -key B_nuc -od ./ -gene B
perl /lustre/work/shufan/bin/HLA_V2/align.nuc.pl -input ../C_nuc.txt -key C_nuc -od ./ -gene C
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl -input ../B_gen.txt -key B_gen -od ./ -gene B
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl -input ../C_gen.txt -key C_gen -od ./ -gene C
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl -input ../DQB1_gen.txt -key DQB1_gen -od ./ -gene DQB1
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl -input ../DPB1_gen.txt -key DPB1_gen -od ./ -gene DPB1
perl /lustre/work/shufan/bin/HLA_V2/align.nuc.pl -input ../DPB1_nuc.txt -key DPB1_nuc -od ./ -gene DPB1
perl /lustre/work/shufan/bin/HLA_V2/align.gen.add.DRB1.pl -input DRB1_gen.align.txt -key DRB1 -od ./
perl /lustre/work/shufan/bin/HLA_V2/align.gen.pl -input ../DPB1_nuc.txt -key DPB1_nuc -od ./ -gene DPB1
head -n 1 *gen.align.txt |grep "_01"|sed 's/^/>/'|sed 's/\t/\n/g'|sed 's/\.//g'|sed 's/|//g' >HLA.ref.fa
