#!/usr/bin/perl -w
# 
# Copyright (c) fanshu 2015
# Writer: fanshu
# Program Date: 2016.
# Modifier: fanshu
# Last Modified: 2016.
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

######################����д����֮ǰ��һ��д��ʱ�䡢������;������˵����ÿ���޸ĳ���ʱ��Ҳ������ע�͹���
my %opts;
GetOptions(\%opts,"input=s","key=s","gene=s","od=s","h" );


if(!defined($opts{input}) || !defined($opts{key}) || !defined($opts{gene})|| !defined($opts{od})|| defined($opts{h}))
{
	print << "Usage End.";

	Description:
	Version: $ver
	Usage:

		-input		align  file				must be given
		-key		output file key name			must be given
		-od		output dir				must be given
		-gene		gene type [A,B,C,DRB1,DQB1,DPB1]	must be given
		-h		Help document
		
Usage End.

	exit;

}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
print "\nStart Time :[$Time_Start]\n\n";
################

my $input=$opts{input}; $input=Absolute_Dir($input,"file");
my $key=$opts{key};
my $gene=$opts{gene}; 
my $od=$opts{od};
$od=Absolute_Dir($od,"dir");

my $Ref;my @exon_start;
if($gene eq "A")
{
	$Ref="A_01_01_01_01";
	@exon_start=(301,504,1015,1870,2248,2807,2982,3199);
}
elsif($gene eq "B")
{
	$Ref="B_07_02_01_01";
	@exon_start=(285,486,1001,1851,2220,2778,2917);
}
elsif($gene eq "C")
{
	$Ref="C_01_02_01_01";
	@exon_start=(496,699,1215,2078,2475,3034,3174,3386);
}
elsif($gene eq "DRB1")
{
	$Ref="DRB1_01_01_01";
	@exon_start=(571,5943,8442,9425,10023,10868);
}
elsif($gene eq "DQB1")
{
	$Ref="DQB1_02_01_01";
	@exon_start=(526,2073,5232,6030,6626,7261);
}
elsif($gene eq "DPB1")
{
	$Ref="DPB1_01_01_01_01";
	@exon_start=(367,5002,9217,10046,10486);
}

my %align;
open (IN,"$input")||die "can't open file $input\n";
while(<IN>)
{
	chomp;
	#next if(/^$/ || /^\#/ || !/\*/);
	next if(/^$/ || /^\#/ );	###for add DRB1
	my @tmp=split/\s+/,$_;
	my $id=$tmp[0];
	#my $id=$tmp[1];
	$id=~s/\*|:/\_/g;
	my $m=join "",@tmp[1..$#tmp];	###for add DRB1
	#my $m=join "",@tmp[1..$#tmp];	###for add DRB1
	$align{$id}.=$m;
}
close IN;

####start from 1
my %Ref_pos;my %gap_pos;
my $ref_seq=$align{$Ref};
$ref_seq=~s/\|//g;
my @base=split//,$ref_seq;
my $gap_num=0;
for(my $j=0;$j<@base;$j++)
{
	if($base[$j] eq ".")
	{
		$gap_pos{$j-$gap_num+1}.="$j,";
		$gap_num++ ;
	}
	else
	{
		$Ref_pos{$j}=$j-$gap_num+1;
	}
}


########
my %mismatch;my %consense;
my %gap;
open (C,">$od/$key.align.txt")||die "can't creat file $od/$key.align.txt\n";
foreach my $id (sort keys %align)
{
	print C "$id\t$align{$id}\n";
	my $seq=$align{$id};
	$seq=~s/\|//g;
	my @base=split//,$seq;
	foreach my $p (sort {$a<=>$b} keys %Ref_pos)
	{
		$consense{$p}{$base[$p]}=1 if($base[$p] ne "-");
		$mismatch{$id}{$p}=$base[$p];
	}
	foreach my $p (sort {$a<=>$b} keys %gap_pos)
	{
		my @pos=split/,/,$gap_pos{$p};
		foreach my $i (@pos)
		{
			$gap{$id}{$p}.=$base[$i] if($base[$i] ne ".");
		}
	}
}
close C;

my $out;
my $flag=0;
my $mis_pos;
foreach my $id (sort keys %align)
{
	my $output;
	foreach my $p (sort {$a<=>$b} keys %Ref_pos)
	{
		if(!exists $consense{$p}){print "$p\n";die;}
		my @con=keys %{$consense{$p}};
		next if(scalar @con ==1);
		#$mis_pos.="$p\t" if($flag==0);
		$mis_pos.="$Ref_pos{$p}\t" if($flag==0);
		$output.=$mismatch{$id}{$p}."\t";
	}
	foreach my $p (sort {$a<=>$b} keys %gap_pos)
	{
		$mis_pos.=$p."-".($p+1)."\t" if($flag==0);
		my $gap=".";
		$gap=$gap{$id}{$p} if(exists $gap{$id}{$p});
		$output.=$gap."\t";
	}
	$output=~s/\t$//;
	$output.="\n";
	if($id eq $Ref){$output=~s/[ATCG]/\-/g;}
	$out.="$id\t$output";

	$flag=1;
}
$mis_pos=~s/\t$//;
open (M,">$od/$key.mismatch.txt")||die "can't creat file $od/$key.mismatch.txt\n";
print M "GT\t$mis_pos\n$out";
close M;




###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
print "\nEnd Time :[$Time_End]\n\n";

###############Subs
sub sub_format_datetime {#Time calculation subroutine
 my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
 $wday = $yday = $isdst = 0;
 sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}


######Absolute_Dir(file,"file") or Absolute_Dir(dir,"dir")
sub Absolute_Dir
{
	my ($ff,$type)=@_;
	my $cur_dir=`pwd`;
	chomp $cur_dir;
	if($ff !~/^\// && $type eq "file")
	{
		$ff=$cur_dir."/".$ff;
	}
	elsif($ff !~/^\// && $type eq "dir")
	{
		$ff=$cur_dir."/".$ff;
		if(!-d $ff){`mkdir -p $ff`}
	}
	elsif($type eq "dir")
	{
		if(!-d $ff){`mkdir -p $ff`}
	}
	return $ff;
}
####fasta format
sub Fasta_format
{
	my ($seq,$len)=@_;
	my $format;
	my @seq=split//,$seq;
	for(my $i=0;$i<length($seq);$i++)
	{
		$format.="$seq[$i]";
		if(($i+1)%$len==0){$format.="\n";}
	}
	if(length($seq)%$len!=0){$format.="\n";}
	return $format;
}
sub H_format{
	my $tmp = $_[0];

	if($tmp =~ /\d*\.\d*$/){
		$tmp = sprintf("%0.2f",$tmp);
		return $tmp;
	}
	elsif($tmp =~ /\d+$/){
		$tmp =reverse $tmp;
		$tmp=~s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
		return reverse($tmp);
	}
	else{
		 return $tmp;
	}
}