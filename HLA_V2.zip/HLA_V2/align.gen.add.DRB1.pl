#!/usr/bin/perl -w
# 
# Copyright (c) fanshu 2015
# Writer: fanshu
# Program Date: 2016.
# Modifier: fanshu
# Last Modified: 2016.
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

######################����д����֮ǰ��һ��д��ʱ�䡢������;������˵����ÿ���޸ĳ���ʱ��Ҳ������ע�͹���
my %opts;
GetOptions(\%opts,"input=s","key=s","od=s","h" );


if(!defined($opts{input}) || !defined($opts{key})|| !defined($opts{od})|| defined($opts{h}))
{
	print << "Usage End.";

	Description:
	Version: $ver
	Usage:

		-input		input file				must be given
		
		-key		output file key name	must be given
		
		-od		output dir				must be given

		-h		Help document
		
Usage End.

	exit;

}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
print "\nStart Time :[$Time_Start]\n\n";
################

my $input=$opts{input}; $input=Absolute_Dir($input,"file");
my $key=$opts{key}; 
my $od=$opts{od};
$od=Absolute_Dir($od,"dir");

my %geno;
open (IN,"$input")||die "can't open file $input\n";
while(<IN>)
{
	chomp;
	my @tmp=split/\t/,$_;
	my @base=split//,$tmp[1];
	for(my $i=0;$i<@base;$i++)
	{
		$geno{$tmp[0]}{$i}=$base[$i];
	}
}
close IN;

foreach my $g (keys %geno)
{
	next if($g eq "DRB1_01_02_01" || $g eq "DRB1_01_01_01");
	foreach my $p (sort {$a<=>$b} keys %{$geno{'DRB1_01_01_01'}})
	{
		if($geno{'DRB1_01_01_01'}{$p} eq "*" && $geno{$g}{$p} eq "*")
		{
			$geno{$g}{$p} =".";
		}
		elsif($geno{'DRB1_01_01_01'}{$p} eq "*" && $geno{$g}{$p} eq "-")
		{
			$geno{$g}{$p} =$geno{'DRB1_01_02_01'}{$p} ;
		}
		elsif($geno{'DRB1_01_01_01'}{$p} =~/[ATCG]/ && $geno{$g}{$p} =~/[ATCG]/)
		{
			$geno{$g}{$p} ="-" if($geno{'DRB1_01_01_01'}{$p} eq $geno{$g}{$p}) ;
		}
	}
}

foreach my $p (sort {$a<=>$b} keys %{$geno{'DRB1_01_01_01'}})
{
	if($geno{'DRB1_01_01_01'}{$p} eq "*" && $geno{'DRB1_01_02_01'}{$p}=~/[ATCG]/)
	{
		$geno{'DRB1_01_01_01'}{$p}=".";
	}
	elsif($geno{'DRB1_01_01_01'}{$p} eq "-" && $geno{'DRB1_01_02_01'}{$p}=~/[ATCG]/)
	{
		$geno{'DRB1_01_01_01'}{$p}=$geno{'DRB1_01_02_01'}{$p};
		$geno{'DRB1_01_02_01'}{$p}="-";
	}
	elsif($geno{'DRB1_01_01_01'}{$p} eq "*" && $geno{'DRB1_01_02_01'}{$p} eq ".")
	{
		$geno{'DRB1_01_01_01'}{$p}=".";
	}
}

open (OUT,">$od/$key.txt")||die "can't creat file $od/$key.txt\n";
foreach my $g (sort keys %geno)
{
	print OUT "$g\t";
	foreach my $p (sort {$a<=>$b} keys %{$geno{$g}})
	{
		print OUT "$geno{$g}{$p}";
	}
	print OUT "\n";
}
close OUT;
###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
print "\nEnd Time :[$Time_End]\n\n";

###############Subs
sub sub_format_datetime {#Time calculation subroutine
 my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
 $wday = $yday = $isdst = 0;
 sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}


######Absolute_Dir(file,"file") or Absolute_Dir(dir,"dir")
sub Absolute_Dir
{
	my ($ff,$type)=@_;
	my $cur_dir=`pwd`;
	chomp $cur_dir;
	if($ff !~/\// && $type eq "file")
	{
		$ff=$cur_dir."/".$ff;
	}
	elsif($ff !~/\// && $type eq "dir")
	{
		$ff=$cur_dir."/".$ff;
		if(!-d $ff){`mkdir -p $ff`}
	}
	elsif($type eq "dir")
	{
		if(!-d $ff){`mkdir -p $ff`}
	}
	return $ff;
}
####fasta format
sub Fasta_format
{
	my ($seq,$len)=@_;
	my $format;
	my @seq=split//,$seq;
	for(my $i=0;$i<length($seq);$i++)
	{
		$format.="$seq[$i]";
		if(($i+1)%$len==0){$format.="\n";}
	}
	if(length($seq)%$len!=0){$format.="\n";}
	return $format;
}
sub H_format{
	my $tmp = $_[0];

	if($tmp =~ /\d*\.\d*$/){
		$tmp = sprintf("%0.2f",$tmp);
		return $tmp;
	}
	elsif($tmp =~ /\d+$/){
		$tmp =reverse $tmp;
		$tmp=~s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
		return reverse($tmp);
	}
	else{
		 return $tmp;
	}
}