#!/usr/bin/perl -w
# 
# Copyright (c) fanshu 2015
# Writer: fanshu
# Program Date: 2016.
# Modifier: fanshu
# Last Modified: 2016.
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);

######################����д����֮ǰ��һ��д��ʱ�䡢������;������˵����ÿ���޸ĳ���ʱ��Ҳ������ע�͹���
my %opts;
GetOptions(\%opts,"adjust=s","gene=s","exon=s","key=s","type=s","od=s","h" );


if(!defined($opts{adjust}) || !defined($opts{gene}) || !defined($opts{exon}) || !defined($opts{key}) || !defined($opts{type})|| !defined($opts{od})|| defined($opts{h}))
{
	print << "Usage End.";

	Description:
	Version: $ver
	Usage:

		-adjust		adjustment fa file				must be given
		-gene		gene consensus file				must be given
		-exon		exon consensus file				must be given
		-key		output file key name			must be given
		-od		output dir				must be given
		-type		gene type [A,B,C,DRB1,DQB1,DPB1]	must be given
		-h		Help document
		
Usage End.

	exit;

}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
print "\nStart Time :[$Time_Start]\n\n";
################

my $adjust=$opts{adjust}; $adjust=Absolute_Dir($adjust,"file");
my $gene=$opts{gene}; $gene=Absolute_Dir($gene,"file");
my $exon=$opts{exon}; $exon=Absolute_Dir($exon,"file");
my $key=$opts{key};
my $type=$opts{type};
my $od=$opts{od};
$od=Absolute_Dir($od,"dir");

my %degenerate=(
"AG" => "R",
"CT" => "Y",
"AC" => "M",
"GT" => "K",
"CG" => "S",
"AT" => "W",
"ACT" => "H",
"CGT" => "B",
"ACG" => "V",
"AGT" => "D",
"ACGT" => "N",
"A" => "A",
"T" => "T",
"C" => "C",
"G" => "G",
);

my $Ref;
if($type eq "A")
{
	$Ref="A_01_01_01_01";
}
elsif($type eq "B")
{
	$Ref="B_07_02_01_01";
}
elsif($type eq "C")
{
	$Ref="C_01_02_01_01";
}
elsif($type eq "DRB1")
{
	$Ref="DRB1_01_01_01";
}
elsif($type eq "DQB1")
{
	$Ref="DQB1_02_01_01";
}
elsif($type eq "DPB1")
{
	$Ref="DPB1_01_01_01_01";
}

my %pos;my @exon_pos;my %info;
my $adjust_seq;
open (IN,"$adjust")||die "can't open file $adjust\n";
while(<IN>)
{
	chomp;
	next if(/^$/ || /^\#/ );
	my @tmp=split//,$_;
	my @t=split/\|/,$_;
	$adjust_seq=$_;
	my $num=0;
	for(my $i=0;$i<@tmp;$i++)
	{
		next if($tmp[$i] eq "N");
		$pos{$i}=$num;
		if($tmp[$i] eq "|")
		{
			push(@exon_pos,$i);
		}
		$num++;
	}
}
close IN;

##################
my %gene_id;
open (O,">$od/$key.alignment.txt")||die "can't creat file $od/$key.alignment.txt\n";
open (G,"$gene")||die "can't open file $gene\n";
while(<G>)
{
	chomp;
	next if(/^$/ || /^\#/);
	my ($id,$seq)=split/\t/,$_;
	my @seq=split//,$seq;
	my $new;
	for(my $i=0;$i<length($adjust_seq);$i++)
	{
		#if(exists $pos{$i}){print $pos{$i};die;}
		$new.=$seq[$pos{$i}] if(exists $pos{$i});
		$new.="." if(!exists $pos{$i});
	}
	print O "$id\t$new\n";
	$gene_id{$id}=1;
	$info{$id}=$new;
}
close G;
#########################
open (E,"$exon")|| die "can't open file $exon\n";
while(<E>)
{
	chomp;
	next if(/^$/ || /^\#/);
	my ($id,$seq)=split/\t/,$_;
	next if(exists $gene_id{$id});
	my @exon=split/\|/,$seq;

	my $new;
	if($type eq "A")
	{
		$new=("*" x $exon_pos[0])."|".$exon[0]."|";

		for(my $i=1;$i<@exon;$i++)
		{
			$new.=("*" x ($exon_pos[2*$i]-$exon_pos[2*$i-1]-1))."|".$exon[$i]."|";
		}
		$new.="*" x (length($adjust_seq)-$exon_pos[-1]);
	}
	print O "$id\t$new\n";
	$info{$id}=$new;
}
close E;

########################get insert position
my %ref_insert;
my $ref_seq=$info{$Ref};
$ref_seq=~s/\|//g;
my @ref=split//,$ref_seq;
my $insert_len=0;
my $start=0;my $last=0;my $flag=0;
my $start_pos=0;
for(my $i=0;$i<@ref;$i++)
{
	if($ref[$i] eq ".")
	{
		$insert_len++;
		if($flag==0)
		{
			$start=$i;
			$start_pos=$i-$insert_len+1;
			$flag=1;
			$last=$i;
		}
		else
		{
			if($i-$last==1)
			{
				$last=$i;
			}
			else
			{
				my $end_pos=$last-$insert_len+3;
				$ref_insert{$start_pos."-".$end_pos}=1;
				$flag=0;
				$last=0;
			}
		}
	}
}

####################get all match
my %mismatch;my %consense;
foreach my $id (sort keys %info)
{
	my $seq=$info{$id};
	$seq=~s/\|//g;
	my @seq=split//,$seq;print "$id\n$seq\n$seq[2324]$seq[2325]$seq[2326]$seq[2327]$seq[2328]$seq[2329]$seq[2330]$seq[2331]$seq[2332]$seq[2333]\n";die;
	for(my $i=0;$i<@seq;$i++)
	{
		if($i ==2329){print "$seq[$i]\n";}
		$mismatch{$id}{$i}=$seq[$i];
		$consense{$i}{$seq[$i]}++ if($seq[$i] ne "-");
	}
}
print Dumper %{$consense{2329}};die;
$insert_len=0;
my %mis_pos;my $consense_seq;
for(my $i=0;$i<length($ref_seq);$i++)
{
	my $base=join "",sort keys %{$consense{$i}};
	my $new=$base;
	$new=~s/\*|\.//g;
	if(!exists $degenerate{$new}){print "$i\n$new\t$base\n";die;}
	$consense_seq.=$degenerate{$new};
	next if(length ($base)==1);
	$mis_pos{$i}=1;
}

open (O,">$od/$key.consense_align.txt")||die "can't creat file $od/$key.consense_align.txt\n";
print O "Consense\t$consense_seq\n";
close O;
`sed \'s\/\|\/\/g\' $od/$key.alignment.txt >> $od/$key.consense_align.txt` ;


###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
print "\nEnd Time :[$Time_End]\n\n";

###############Subs
sub sub_format_datetime {#Time calculation subroutine
 my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
 $wday = $yday = $isdst = 0;
 sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}


######Absolute_Dir(file,"file") or Absolute_Dir(dir,"dir")
sub Absolute_Dir
{
	my ($ff,$type)=@_;
	my $cur_dir=`pwd`;
	chomp $cur_dir;
	if($ff !~/^\// && $type eq "file")
	{
		$ff=$cur_dir."/".$ff;
	}
	elsif($ff !~/^\// && $type eq "dir")
	{
		$ff=$cur_dir."/".$ff;
		if(!-d $ff){`mkdir -p $ff`}
	}
	elsif($type eq "dir")
	{
		if(!-d $ff){`mkdir -p $ff`}
	}
	return $ff;
}
####fasta format
sub Fasta_format
{
	my ($seq,$len)=@_;
	my $format;
	my @seq=split//,$seq;
	for(my $i=0;$i<length($seq);$i++)
	{
		$format.="$seq[$i]";
		if(($i+1)%$len==0){$format.="\n";}
	}
	if(length($seq)%$len!=0){$format.="\n";}
	return $format;
}
sub H_format{
	my $tmp = $_[0];

	if($tmp =~ /\d*\.\d*$/){
		$tmp = sprintf("%0.2f",$tmp);
		return $tmp;
	}
	elsif($tmp =~ /\d+$/){
		$tmp =reverse $tmp;
		$tmp=~s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
		return reverse($tmp);
	}
	else{
		 return $tmp;
	}
}