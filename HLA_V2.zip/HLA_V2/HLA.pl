#!/usr/bin/perl -w
# 
# Copyright (c) fanshu 2015
# Writer: fanshu
# Program Date: 2016.
# Modifier: fanshu
# Last Modified: 2016.
my $ver="1.0";

use strict;
use Getopt::Long;
use Data::Dumper;
use FindBin qw($Bin $Script);
use File::Basename qw(basename dirname);
use Parallel::ForkManager;
use POE::Session;
use POE::Kernel;
######################����д����֮ǰ��һ��д��ʱ�䡢������;������˵����ÿ���޸ĳ���ʱ��Ҳ������ע�͹���
my %opts;
GetOptions(\%opts,"fq=s","ref=s","od=s","h" );


if(!defined($opts{fq}) || !defined($opts{od})|| defined($opts{h}))
{
	print << "Usage End.";

	Description:
	Version: $ver
	Usage:

		-fq		fq list file				must be given
		-ref		ref file				option
		-od		output dir				must be given
		-h		Help document
		
Usage End.

	exit;

}

###############Time
my $Time_Start;
$Time_Start = sub_format_datetime(localtime(time()));
print "\nStart Time :[$Time_Start]\n\n";
################

my $fq=$opts{fq}; $fq=Absolute_Dir($fq,"file");
my $ref=defined $opts{ref}? $opts{ref}:" "; $ref=Absolute_Dir($ref,"file");
my $step=defined $opts{step}?$opts{step}:1; 
my $od=$opts{od};$od=Absolute_Dir($od,"dir");
#####
my $perl="/usr/bin/perl";
my $BWA = "/usr/bin/bwa";
my $Ref="/lustre/work/shufan/RD/Database/IPD-IMGT_HLA/Release_3.31.0/alignments/format/HLA.ref.fa";
my $SAMTOOLS="/lustre/software/target/samtools-1.2/bin/samtools";
my $mis_dir="/lustre/work/shufan/RD/Database/IPD-IMGT_HLA/Release_3.31.0/alignments/format/";
####

my %list;
read_fq($fq,\%list);
my $header = "\'\@RG\\tID:foo\\tLB:bar\\tPL:illumina\\tPU:illumina\\tSM:bar\'";


####start genotype
my @gene1=("A");
#my @gene1=("A","C","B","DQB1","DRB1","DPB1");
#my @gene1=("DQB1","DRB1","DPB1");
foreach my $f (sort keys %list) 
{
	my $shell="$od/$f/shell"; $shell=Absolute_Dir($shell,"dir");
	open (SH,">$shell/$f.sh")||die "can't creat file $shell/$f.sh\n";
	my $align="$od/$f/align";$align=Absolute_Dir($align,"dir");
	print SH "$BWA mem -t 24 $Ref $list{$f}{fq1} $list{$f}{fq2} | $SAMTOOLS view -b -F 4 - |$SAMTOOLS sort - $align/$f.sort \n";
	`$BWA mem -t 24 -R $header $Ref $list{$f}{fq1} $list{$f}{fq2} | $SAMTOOLS view -b -F 4 - |$SAMTOOLS sort - $align/$f.sort `;
	foreach my $g (@gene1) 
	{
		print SH "$perl $Bin/bin/basic.stat.v2.pl -in $align/$f.sort.bam -od $align -name $g -mis $mis_dir/$g\_nuc.mismatch.txt \n";
		`$perl $Bin/bin/basic.stat.v2.pl -in $align/$f.sort.bam -od $align -name $g -mis $mis_dir/$g\_nuc.mismatch.txt `;
	}
	close SH;
}
close SH;




###############Time
my $Time_End;
$Time_End = sub_format_datetime(localtime(time()));
print "\nEnd Time :[$Time_End]\n\n";

###############Subs
sub sub_format_datetime {#Time calculation subroutine
 my($sec, $min, $hour, $day, $mon, $year, $wday, $yday, $isdst) = @_;
 $wday = $yday = $isdst = 0;
 sprintf("%4d-%02d-%02d %02d:%02d:%02d", $year+1900, $mon+1, $day, $hour, $min, $sec);
}


######Absolute_Dir(file,"file") or Absolute_Dir(dir,"dir")
sub Absolute_Dir
{
	my ($ff,$type)=@_;
	my $cur_dir=`pwd`;
	chomp $cur_dir;
	if($ff !~/^\// && $type eq "file")
	{
		$ff=$cur_dir."/".$ff;
	}
	elsif($ff !~/^\// && $type eq "dir")
	{
		$ff=$cur_dir."/".$ff;
		if(!-d $ff){`mkdir -p $ff`}
	}
	elsif($type eq "dir")
	{
		if(!-d $ff){`mkdir -p $ff`}
	}
	return $ff;
}
####fasta format
sub Fasta_format
{
	my ($seq,$len)=@_;
	my $format;
	my @seq=split//,$seq;
	for(my $i=0;$i<length($seq);$i++)
	{
		$format.="$seq[$i]";
		if(($i+1)%$len==0){$format.="\n";}
	}
	if(length($seq)%$len!=0){$format.="\n";}
	return $format;
}
sub H_format{
	my $tmp = $_[0];

	if($tmp =~ /\d*\.\d*$/){
		$tmp = sprintf("%0.2f",$tmp);
		return $tmp;
	}
	elsif($tmp =~ /\d+$/){
		$tmp =reverse $tmp;
		$tmp=~s/(\d\d\d)(?=\d)(?!\d*\.)/$1,/g;
		return reverse($tmp);
	}
	else{
		 return $tmp;
	}
}

sub read_fq
{
	my ($file,$list)=@_;
	open (IN,$file)||die "can't open $file\n";
	while(<IN>)
	{
		chomp;
		s/\r//g;
		next if(/^$/||/^\#/);
		my @tmp=split/\s+/,$_;
		$$list{$tmp[0]}{fq1}=$tmp[1];
		$$list{$tmp[0]}{fq2}=$tmp[2];
	}
}

sub BWA
{
	my ($s,$g,$dir,$db)=@_;
	my @fa=glob("$db/$g/*.fa");
	my $header = "\'\@RG\\tID:foo\\tLB:bar\\tPL:illumina\\tPU:illumina\\tSM:bar\'";
	my $pm = Parallel::ForkManager->new(60);
	foreach my $f (@fa)
	{
		$pm->start and next;
		my $name=basename($f);
		`$BWA mem -t 24 -R $header \'$f\' $$s{fq1} $$s{fq2} >$dir/$name.sam`;
		#`$BWA mem -t 4 -R $header \'$f\' $$s{fq1} $$s{fq2} |$SAMTOOLS view -F 0x4 -bSh -o \'$dir/$name.bam\' -  `;
		#`$SAMTOOLS sort '$dir/$name.bam' '$dir/$name.sort' `;
		#`$SAMTOOLS index '$dir/$name.sort.bam' `;
		$pm->finish;
	}
}

